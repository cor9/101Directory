# Child Actor 101: Resource Directory

This is the static front page for the Child Actor 101 vendor directory.

## 🧾 Deploy on Render

1. Go to [https://render.com](https://render.com)
2. Click "New Static Site"
3. Connect your GitHub repo
4. Use the following:
   - Build command: _(leave blank)_
   - Publish directory: `.`
5. Done! 🎉

Optional: Point your subdomain from Squarespace:
   - CNAME → your Render address

## 🛠️ Local Development

To run locally, just open `index.html` in your browser.
